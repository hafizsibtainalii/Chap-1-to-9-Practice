// Q1: Add two numbers
var num1 = 3;
var num2 = 5;
var sum = num1 + num2;
document.write("Sum of " + num1 + " and " + num2 + " is " + sum + "<br><br>");

// Q2: Subtraction, multiplication, division, modulus
document.write("Subtraction: " + (num1 - num2) + "<br>");
document.write("Multiplication: " + (num1 * num2) + "<br>");
document.write("Division: " + (num1 / num2) + "<br>");
document.write("Modulus: " + (num1 % num2) + "<br><br>");

// Q3: Step by step
var x;
document.write("Value after variable declaration is: " + x + "<br>");
x = 5;
document.write("Initial value: " + x + "<br>");
x++;
document.write("Value after increment is: " + x + "<br>");
x = x + 7;
document.write("Value after addition is: " + x + "<br>");
x--;
document.write("Value after decrement is: " + x + "<br>");
document.write("The remainder is: " + (x % 3) + "<br><br>");

// Q4: Movie tickets
var ticketPrice = 600;
document.write("Total cost to buy 5 tickets to a movie is " + (ticketPrice * 5) + "PKR<br><br>");

// Q5: Multiplication table
var tableNumber = 4;
document.write("Table of " + tableNumber + "<br>");
for (var i = 1; i <= 10; i++) {
  document.write(tableNumber + "x" + i + "=" + (tableNumber * i) + "<br>");
}
document.write("<br>");

// Q6: Temperature converter
var celsius = 25;
var fahrenheit = (celsius * 9 / 5) + 32;
document.write(celsius + "°C is " + fahrenheit + "°F<br>");

var fahr = 70;
var cel = (fahr - 32) * 5 / 9;
document.write(fahr + "°F is " + cel + "°C<br><br>");

// Q7: Shopping cart
var price1 = 650;
var price2 = 100;
var qty1 = 3;
var qty2 = 7;
var shipping = 100;
var total = (price1 * qty1) + (price2 * qty2) + shipping;

document.write("<h1>Shopping Cart</h1>");
document.write("Price of item 1 is " + price1 + "<br>");
document.write("Quantity of item 1 is " + qty1 + "<br>");
document.write("Price of item 2 is " + price2 + "<br>");
document.write("Quantity of item 2 is " + qty2 + "<br>");
document.write("Shipping Charges " + shipping + "<br><br>");
document.write("Total cost of your order is " + total + "<br><br>");

// Q8: Marks sheet
var totalMarks = 980;
var marksObtained = 804;
var percentage = (marksObtained / totalMarks) * 100;

document.write("<h1>Marks Sheet</h1>");
document.write("Total marks: " + totalMarks + "<br>");
document.write("Marks obtained: " + marksObtained + "<br>");
document.write("Percentage: " + percentage + "%<br><br>");

// Q9: Currency in one expression
var pkr = (10 * 104.80) + (25 * 28);
document.write("<h1>Currency in PKR</h1>");
document.write("Total Currency in PKR: " + pkr + "<br><br>");

// Q10: Add 5, multiply by 10, divide by 2 (one expression)
var number = 5;
var result = (number + 5) * 10 / 2;
document.write("Result: " + result + "<br><br>");

// Q11: Age calculator
var currentYear = 2016;
var birthYear = 1992;
var age1 = currentYear - birthYear;
var age2 = age1 - 1;
document.write("<h1>Age Calculator</h1>");
document.write("Current Year: " + currentYear + "<br>");
document.write("Birth Year: " + birthYear + "<br>");
document.write("They are either " + age2 + " or " + age1 + " years old<br><br>");

// Q12: Circle
var radius = 20;
var pi = 3.142;
var circumference = 2 * pi * radius;
var area = pi * radius * radius;
document.write("<h1>The Geometrizer</h1>");
document.write("Radius of a circle: " + radius + "<br>");
document.write("The circumference is: " + circumference + "<br>");
document.write("The area is: " + area + "<br><br>");

// Q13: Lifetime supply
var snack = "chocolate chip";
var currentAge = 15;
var maxAge = 65;
var perDay = 3;
var totalSnacks = (maxAge - currentAge) * 365 * perDay;
document.write("<h1>The Lifetime Supply Calculator</h1>");
document.write("You will need " + totalSnacks + " " + snack + " to last you until the ripe old age of " + maxAge);