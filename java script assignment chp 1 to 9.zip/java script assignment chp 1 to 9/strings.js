// Q1
var username;

// Q2
var myName = "Ali Khan";

// Q3
var message;
message = "Hello World";
alert(message);

// Q4: Student bio data
var studentName = "John Doe";
var studentAge = "15 years old";
var course = "Certified Mobile Application Development";
alert(studentName);
alert(studentAge);
alert(course);

// Q5: One variable, many lines
var pizza = "PIZZA\nPIZZ\nPIZ\nPI\nP";
alert(pizza);

// Q6: String concatenation
var email = "example@example.com";
alert("My email address is " + email);

// Q7
var book = "A smarter way to learn JavaScript";
alert("I am trying to learn from the Book " + book);

// Q8: Write on the browser page
document.write("Yah! I can write HTML content through JavaScript");

// Q9: Special string in alert and browser
var line = "▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬";
alert(line);
document.write(line);