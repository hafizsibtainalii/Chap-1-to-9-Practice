// Q1: Array of 3 names, then add one using push()
var students = ["Ali", "Sara", "Ahmed"];
students.push("Hina");
document.write("Q1: " + students + "<br><br>");

// Q2: Remove last item using pop()
var fruits = ["Apple", "Banana", "Mango", "Orange"];
fruits.pop();
document.write("Q2: " + fruits + "<br><br>");

// Q3: Add "Monday" to the beginning using unshift()
var days = ["Tuesday", "Wednesday", "Thursday"];
days.unshift("Monday");
document.write("Q3: " + days + "<br><br>");

// Q4: Remove first item using shift()
var colors = ["Red", "Green", "Blue"];
colors.shift();
document.write("Q4: " + colors + "<br><br>");

// Q5: Insert "Math" and "Science" at index 2 using splice()
var subjects = ["English", "Urdu", "Physics", "Chemistry"];
subjects.splice(2, 0, "Math", "Science");
document.write("Q5: " + subjects + "<br><br>");

// Q6: Remove 2 elements starting from index 1 using splice()
var cities = ["Karachi", "Lahore", "Islamabad", "Quetta", "Peshawar"];
cities.splice(1, 2);
document.write("Q6: " + cities + "<br><br>");

// Q7: Get first 3 items using slice()
var countries = ["Pakistan", "India", "China", "Japan", "Turkey"];
var firstThree = countries.slice(0, 3);
document.write("Q7: " + firstThree + "<br><br>");

// Q8: Convert string to array using split()
var fruitString = "apple,banana,mango";
var fruitArray = fruitString.split(",");
document.write("Q8: " + fruitArray + "<br><br>");

// Q9: Join array of characters into a string using join()
var chars = ['J', 'S'];
var word = chars.join("");
document.write("Q9: " + word + "<br><br>");

// Q10: Combine two arrays using concat()
var arr1 = ['pen', 'pencil'];
var arr2 = ['eraser', 'sharpener'];
var stationery = arr1.concat(arr2);
document.write("Q10: " + stationery + "<br><br>");

// Q11: Sort numbers using sort() (sorts as strings)
var numbers = [10, 5, 2, 8];
numbers.sort();
document.write("Q11: " + numbers + "<br><br>");

// Q12: Sort names alphabetically using sort()
var names = ["Sara", "Ali", "Zain", "Hina", "Bilal"];
names.sort();
document.write("Q12: " + names + "<br><br>");

// Q13: Reverse an array of numbers using reverse()
var nums = [1, 2, 3, 4, 5];
nums.reverse();
document.write("Q13: " + nums + "<br><br>");

// Q14: Find index of "Blue" using indexOf()
var colorList = ["Red", "Green", "Blue", "Yellow"];
document.write("Q14: Index of Blue is " + colorList.indexOf("Blue") + "<br><br>");

// Q15: Add three items to an empty array using push()
var emptyArr = [];
emptyArr.push("Pen");
emptyArr.push("Book");
emptyArr.push("Bag");
document.write("Q15: " + emptyArr + "<br><br>");

// Q16: Remove the middle item (index 2) from 5 numbers using splice()
var fiveNums = [10, 20, 30, 40, 50];
fiveNums.splice(2, 1);
document.write("Q16: " + fiveNums + "<br><br>");

// Q17: String to array using split()
var text = "HTML CSS JavaScript";
var textArr = text.split(" ");
document.write("Q17: " + textArr + "<br><br>");

// Q18: Reverse ['a','b','c'] then join with "-"
var letters = ['a', 'b', 'c'];
letters.reverse();
var joined = letters.join("-");
document.write("Q18: " + joined + "<br><br>");

// Q19: Check if "Karachi" exists using indexOf() and show its index
var places = ["Lahore", "Multan", "Karachi", "Quetta"];
var index = places.indexOf("Karachi");
if (index !== -1) {
  document.write("Q19: Karachi exists at index " + index + "<br><br>");
} else {
  document.write("Q19: Karachi does not exist in the array<br><br>");
}

// Q20: Concat even and odd arrays, then reverse
var even = [2, 4, 6, 8];
var odd = [1, 3, 5, 7];
var all = even.concat(odd);
all.reverse();
document.write("Q20: " + all + "<br><br>");