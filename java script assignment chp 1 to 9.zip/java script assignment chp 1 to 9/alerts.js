// Q1: Greet the visitor
alert("Welcome to my website!");

// Q2: Error message
alert("Error! Please enter a valid password.");

// Q3: Message on two lines (\n is the line break)
alert("Welcome to JS Land...\nHappy Coding!");

// Q4: Messages in sequence (second one shows after you click OK)
alert("Welcome to JS Land...");
alert("Happy Coding!");

// Q: Alerts
alert("Hello... I can run JS through my web browser's console");