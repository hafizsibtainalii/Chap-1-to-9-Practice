// Q1: 3 variables in one statement
var a = 10, b = 20, c = 30;

// Q2: 5 legal variable names
var name1 = "Ali";
var _age = 20;
var $price = 500;
var my_1stVariable = "ok";
var userName = "Sara";

// 5 illegal variable names (kept as comments, because they would give errors)
// var 1name = "Ali";        // cannot start with a number
// var my-name = "Ali";      // "-" is not allowed
// var user name = "Ali";    // space is not allowed
// var var = 5;              // keyword cannot be used
// var @email = "a@b.com";   // "@" is not allowed

// Q3: Show rules in browser
document.write("<h1>Rules for naming JS variables</h1>");
document.write("Variable names can only contain letters, numbers, $ and _ . For example : $my_1stVariable<br>");
document.write("Variable must begin with a letter, $ or _ . For example : $name, _name or name<br>");
document.write("Variable names are case sensitive<br>");
document.write("Variable names should not be JS keywords");