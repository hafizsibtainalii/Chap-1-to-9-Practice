// Q1: Increment and decrement
var a = 10;
document.write("Result:<br>");
document.write("The value of a is: " + a + "<br>");
document.write("..............................<br><br>");

document.write("The value of ++a is: " + (++a) + "<br>");
document.write("Now the value of a is: " + a + "<br><br>");

document.write("The value of a++ is: " + (a++) + "<br>");
document.write("Now the value of a is: " + a + "<br><br>");

document.write("The value of --a is: " + (--a) + "<br>");
document.write("Now the value of a is: " + a + "<br><br>");

document.write("The value of a-- is: " + (a--) + "<br>");
document.write("Now the value of a is: " + a + "<br><br>");

// Q2: var a = 2, b = 1; var result = --a - --b + ++b + b--;
var p = 2, q = 1;
var res = --p - --q + ++q + q--;
document.write("p is " + p + "<br>");
document.write("q is " + q + "<br>");
document.write("result is " + res + "<br><br>");

/* Explanation at each stage (start: a = 2, b = 1):
   --a                      -> a becomes 1, value is 1
   --a - --b                -> b becomes 0, so 1 - 0 = 1
   --a - --b + ++b          -> b becomes 1, so 1 + 1 = 2
   --a - --b + ++b + b--    -> value of b is 1 (then b becomes 0), so 2 + 1 = 3
   Final: a = 1, b = 0, result = 3
*/

// Q3: Take name from user and greet
var userName = prompt("Enter your name:");
alert("Hello " + userName + "! Welcome.");

// Q5: Multiplication table (default is 5)
var n = prompt("Enter a number for its table:");
if (n == "" || n == null) {
  n = 5;
}
n = Number(n);
document.write("<br>Table of " + n + "<br>");
for (var i = 1; i <= 10; i++) {
  document.write(n + " x " + i + " = " + (n * i) + "<br>");
}

// Q6: Subjects and marks
var sub1 = prompt("Enter name of subject 1:");
var sub2 = prompt("Enter name of subject 2:");
var sub3 = prompt("Enter name of subject 3:");
var total = 100;

var marks1 = Number(prompt("Enter obtained marks of " + sub1 + ":"));
var marks2 = Number(prompt("Enter obtained marks of " + sub2 + ":"));
var marks3 = Number(prompt("Enter obtained marks of " + sub3 + ":"));

var allTotal = total * 3;
var allObtained = marks1 + marks2 + marks3;
var allPercentage = (allObtained / allTotal) * 100;

document.write("<br><table border='1' cellpadding='8'>");
document.write("<tr><th>Subject</th><th>Total Marks</th><th>Obtained Marks</th><th>Percentage</th></tr>");
document.write("<tr><td>" + sub1 + "</td><td>" + total + "</td><td>" + marks1 + "</td><td>" + (marks1 / total * 100) + "%</td></tr>");
document.write("<tr><td>" + sub2 + "</td><td>" + total + "</td><td>" + marks2 + "</td><td>" + (marks2 / total * 100) + "%</td></tr>");
document.write("<tr><td>" + sub3 + "</td><td>" + total + "</td><td>" + marks3 + "</td><td>" + (marks3 / total * 100) + "%</td></tr>");
document.write("<tr><th></th><th>" + allTotal + "</th><th>" + allObtained + "</th><th>" + allPercentage + "%</th></tr>");
document.write("</table>");