// Q1
var age = 15;
alert("I am " + age + " years old");

// Q2
var visits = 14;
alert("You have visited this site " + visits + " times");

// Q3
var birthYear = 1990;
document.write("My birth year is " + birthYear + "<br>");
document.write("Data type of my declared variable is " + typeof birthYear);

// Q4: Online clothing store
document.write("<br><br>");
var visitorName = "John Doe";
var productTitle = "T-shirt";
var quantity = 5;
document.write("<b>" + visitorName + "</b> ordered <b>" + quantity + " " + productTitle + "</b>(s) on XYZ Clothing store");